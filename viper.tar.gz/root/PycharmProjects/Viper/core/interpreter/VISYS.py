import json


import os
print(os.path.dirname(os.path.abspath(__file__)))


with open("interpreter/distros/info.json", "r") as dinfo:
    distroInfo = json.loads(dinfo.read())