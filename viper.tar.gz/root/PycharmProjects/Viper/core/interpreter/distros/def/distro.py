# This is simply a placeholder distro that does absolutely nothing other then bug the user that they need to get an actuall distro.
import os

def executeViper(lineinfo):
    os.system("echo You need to install a distro to use Viper!")
    return 0