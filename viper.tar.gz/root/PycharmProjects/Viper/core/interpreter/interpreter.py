# Developed by Shaun Johnson on a Linux Debian machine provided by Stevenc21. (See the companion github organization)
# Written for python 3.5.
# Called to by either a shell file or a batch file with at least one parameter.
# Import cycle:
#    _init()
#    _init_check()
# Parameters: '<>' means optional, '[]' means required.
#    [Path to file]
#    <Distro to interpret with>

"""viper/core/interpreter.py"""

# Imports
import sys
#import VISYS

# Initalization Functions
def _init():
    """Initalizes variables and such"""
    global logs # Makes logs accessable to '_init_check()'
    logs = {}
def _init_check():
    """Checks to make sure everything is okay when being run"""
    logs["checks"] = {} # Adding the '_init_check()` dictionary to the logs.
    logs["checks"]["parameterCountValid"] = len(sys.argv) > 1 # Makes sure there is at least one parameter passed to the file.
    for key, value in logs["checks"].items():
        # Now that we've checked everything we need to, let's make sure there were no 'false' checks.
        errors = [] # Create a list that we can put any check errors in.
        if value == False:
            errors.append("Check {0} did not pass with value {1}".format(key, value)) # Error!
    if len(errors) > 0: # If there were any erorrs...
        for error in errors:
            print(error) # Notify the user of their evil ways.
        return 1 # Bad boy.
    else:
        return 0 # Good boy. :3

# Interpretation Functions
def getLines():
    """Get the lines of the viper file passed to the interpreter."""
    with open(sys.argv[1], "r") as file: # Get the file passed through the shell.
        return file.readlines() # Return the lines in the file.
def getLineInfo(line):
    """Returns a dictionary with infromation concerning the line passed to it

    Sample return value:
        {"functAttr":["async"],"functName":"foo",parameters:[":bar", "12"]}
    The viper equavalent is:
        async foo(:bar, 12)
    """
    params = line.split("(")
    preParam = params[0]
    postParam = params[1]
    name = preParam.split()[-1] # functName
    preParam = preParam.split()
    preParam.pop()
    if len(preParam) > 0:
        attr = preParam # functAttr
    else:
        attr = [] # functAttr
    postParam = postParam.split(", ")
    parameters = postParam[-1][:-1] # Parameters
    return {
        "functAttr" : attr,
        "functName" : name,
        "parameters": parameters
    }
def getAllLineInfo():
    info = []
    for line in getLines():
        info.append(getLineInfo())
    return info

print(getLineInfo("very_scary dad joke()"))

_init()
if _init_check() == 0: # If all checks passed
    distro = __import__(VISYS.distroInfo["default"]+"distro.py")
    distro.executeViper(getAllLineInfo())